// Selecionar DOM
const todoInput = document.querySelector(".todo-input");
const todoButton = document.querySelector(".todo-button");
const todoList = document.querySelector(".todo-list");
const filterOption = document.querySelector(".filter-todo");
const deleteAllButton = document.querySelector(".delete-all");
const noToDoItemText = document.querySelector(".no-to-do-item");
const priorityInput = document.getElementById("priorityInput");
let ctn = 0;

// Ouvintes de evento
document.addEventListener("DOMContentLoaded", obterTarefas);
todoButton.addEventListener("click", adicionarTarefa);
todoList.addEventListener("click", excluirTarefa);
filterOption.addEventListener("change", filtrarTarefas);

var modal = document.getElementById("myModal");
var btn = document.getElementById("myBtn");
var textField = document.getElementById("textInput");
var span = document.getElementsByClassName("close")[0];
var addBtn = document.getElementById("todo-button");

// Funções
function verificarListaVazia() {
  if (localStorage.getItem("todos") === null) {
    deleteAllButton.classList.add("hide");
    noToDoItemText.classList.remove("hide");
  } else {
    if (obterItemDoLocalStorage().length == 0) {
      deleteAllButton.classList.add("hide");
      noToDoItemText.classList.remove("hide");
    } else {
      deleteAllButton.classList.remove("hide");
      noToDoItemText.classList.add("hide");
    }
  }
}
setInterval(verificarListaVazia, 100);

function htmlEncode(str) {
  return String(str);
}

function obterItemDoLocalStorage() {
  const todos = JSON.parse(localStorage.getItem("todos")) || [];
  return todos;
}

function adicionarTarefa(e) {
  const textoSel = priorityInput.options[priorityInput.selectedIndex].text;
  ctn += 1;
  // Prevenir comportamento natural
  e.preventDefault();

  const d = new Date();
  const valorAtual = htmlEncode(todoInput.value)?.trim() || "";
  if (!valorAtual) {
    abrirModal("red", "Por favor, insira uma tarefa!");
    return;
  }

  if (!/\D/.test(valorAtual) == true) {
    abrirModal("red", "Não insira apenas números, por favor, insira uma tarefa válida!");
    return;
  }

  if (isDuplicate(valorAtual)) {
    abrirModal("red", "Esta tarefa já foi adicionada!");
    return;
  }

  // Criar div de tarefa
  const todoDiv = document.createElement("div");
  todoDiv.classList.add("todo");
  console.log(textoSel)

  // Usar a variável textoSel para determinar a cor de fundo
  if (textoSel == "Alta") {
    todoDiv.style.backgroundColor = "red";  // Alta -> vermelho
  } else if (textoSel == "Média") {
    todoDiv.style.backgroundColor = "yellow";  // Média -> amarelo
  } else if (textoSel == "Baixa") {
    todoDiv.style.backgroundColor = "green";  // Baixa -> verde
  }

  // Criar item de lista
  const novaTarefa = document.createElement("li");
  novaTarefa.innerText = valorAtual;
  let novoItemTarefa = {
    id: ctn, // id para seleção
    tarefa: valorAtual,
    status: "incompleta",
    prioridade: textoSel // armazenar a prioridade
  };
  todoDiv.setAttribute("key", novoItemTarefa.id);

  // Salvar o novo item de tarefa no localStorage
  salvarTarefasNoLocalStorage(novoItemTarefa);

  novaTarefa.classList.add("todo-item");
  todoDiv.appendChild(novaTarefa);
  todoInput.value = "";

  // Criar formulário de edição para edição posterior
  const editar = document.createElement("div");
  editar.innerHTML =
    `<form class="editform">
      <input type="text" placeholder=` +
    `"${novoItemTarefa.tarefa}"` +
    `id="edit-${novoItemTarefa.id}" required />
      <div class="editDiv" style="margin:auto;">
        <button id="editBtn-${novoItemTarefa.id}" type="submit">
          <i class="fas fa-plus-square"></i>
        </button>
      </div>
    </form>`;
  editar.classList.add("hide");
  todoDiv.appendChild(editar);

  // Criar botão de concluído
  const completedButton = document.createElement("button");
  completedButton.innerHTML = `<i class="fas fa-check"></i>`;
  completedButton.classList.add("complete-btn");
  todoDiv.appendChild(completedButton);

  // Criar botão de editar
  const editButton = document.createElement("button");
  editButton.innerHTML = `<i class="fas fa-pen"></i>`;
  editButton.classList.add("edit-btn");
  editButton.addEventListener("click", () => editarTarefa(novoItemTarefa, todoDiv));
  todoDiv.appendChild(editButton);

  // Criar botão de excluir
  const trashButton = document.createElement("button");
  trashButton.innerHTML = `<i class="fas fa-trash"></i>`;
  trashButton.classList.add("trash-btn");
  todoDiv.appendChild(trashButton);

  // Criar botão de info
  const infoButton = document.createElement("span");
  infoButton.innerHTML = `<i class="fas fa-info-circle"></i>`;
  infoButton.classList.add("edit-btn");
  todoDiv.appendChild(infoButton);

  // Anexar item final de tarefa à lista
  todoList.appendChild(todoDiv);

  // Verificar se o modo escuro está ativo e aplicar estilos
  if (localStorage.getItem("display-theme") == "dark") {
    todoDiv.classList.toggle("dark-mode");
    novaTarefa.classList.toggle("dark-mode");
  }

  setAggregatedToDos();
}

function excluirTarefa(e) {
  const item = e.target;

  if (item.classList[0] === "trash-btn") {
    e.preventDefault();
    const caixaConfirmacao = document.getElementById("custom-confirm");
    const botaoConfirmarSim = document.getElementById("confirm-yes");
    const botaoConfirmarNao = document.getElementById("confirm-no");
    const botaoCancelarConfirmacao = document.getElementById("confirm-cancel");
    const todo = item.parentElement;

    const handleSimClick = () => {
      caixaConfirmacao.style.display = "none";
      todo.classList.add("fall");
      removerTarefasDoLocalStorage(todo);
      todo.addEventListener("transitionend", () => {
        todo.remove();
      });
      botaoConfirmarSim.removeEventListener("click", handleSimClick);
      botaoConfirmarNao.removeEventListener("click", handleNaoClick);
      botaoCancelarConfirmacao.removeEventListener("click", handleCancelarClick);
    };

    const handleNaoClick = () => {
      caixaConfirmacao.style.display = "none";
      botaoConfirmarSim.removeEventListener("click", handleSimClick);
      botaoConfirmarNao.removeEventListener("click", handleNaoClick);
      botaoCancelarConfirmacao.removeEventListener("click", handleCancelarClick);
    };

    const handleCancelarClick = () => {
      caixaConfirmacao.style.display = "none";
      botaoConfirmarSim.removeEventListener("click", handleSimClick);
      botaoConfirmarNao.removeEventListener("click", handleNaoClick);
      botaoCancelarConfirmacao.removeEventListener("click", handleCancelarClick);
    };

    botaoConfirmarSim.addEventListener("click", handleSimClick);
    botaoConfirmarNao.addEventListener("click", handleNaoClick);
    botaoCancelarConfirmacao.addEventListener("click", handleCancelarClick);

    caixaConfirmacao.style.display = "block";
  }

  if (item.classList[0] === "complete-btn") {
    const todo = item.parentElement;
    todo.classList.toggle("completed");
    const status = "completed";
    const id = todo.getAttribute("key");
    salvarStatus(id, status);
    verificarSeTodasTarefasEstaoConcluídas();
  }

  setAggregatedToDos();
}

function obterTarefas() {
    let todos;
    if (localStorage.getItem("todos") === null) {
      todos = [];
    } else {
      todos = JSON.parse(localStorage.getItem("todos"));
    }
  
    todos.forEach(function (todo) {
      //Create todo div
      const todoDiv = document.createElement("div");
      todoDiv.classList.add("todo");
      if (todo.status == "completed") {
        todoDiv.classList.toggle("completed");
      }
      //Create list
      const newTodo = document.createElement("li");
      newTodo.innerText = todo.task;
      newTodo.classList.add("todo-item");
      todoDiv.appendChild(newTodo);
      todoInput.value = "";
      //input box
      const edit = document.createElement("div");
      edit.innerHTML =
      `<form class="editform">
        <input type="text" placeholder=` +
          `"${todo.task}"` +
          `id="` +
          `edit-${todo.id}` +
          `" required />
        <div class="editDiv" style="margin:auto;">
          <button id="editBtn-` +
            `${todo.id}` +
            `" type="submit">
            <i class="fas fa-plus-square"></i>
          </button>
        </div>
      </form>`;
      edit.classList.add("hide");
      todoDiv.appendChild(edit);
      //Create Completed Button
      const completedButton = document.createElement("button");
      completedButton.innerHTML = `<i class="fas fa-check"></i>`;
      completedButton.classList.add("complete-btn");
      todoDiv.appendChild(completedButton);
      //Create edit button
      const editButton = document.createElement("button");
      editButton.innerHTML = `<i class="fas fa-pen"></i>`;
      editButton.classList.add("edit-btn");
      editButton.addEventListener("click", () => editTodo(todo, todoDiv));
      todoDiv.appendChild(editButton);
      //Create trash button
      const trashButton = document.createElement("button");
      trashButton.innerHTML = `<i class="fas fa-trash"></i>`;
      trashButton.classList.add("trash-btn");
      todoDiv.setAttribute("key", todo.id);
      todoDiv.appendChild(trashButton);
      //Create info button
      if (!todo.infoText) todo.infoText = "Create time not found.";
      const infoButton = document.createElement("span");
      infoButton.innerHTML = `<i class="fas fa-info-circle"></i>`;
      infoButton.classList.add("edit-btn");
      todoDiv.appendChild(infoButton);
      //attach final Todo
      todoList.appendChild(todoDiv);
      if (localStorage.getItem("display-theme") == "dark") {
        todoDiv.classList.toggle("dark-mode");
      }
    });
  
    setAggregatedToDos();
  }

// Salvar o status da tarefa -> e persistir salvando no localStorage
function salvarStatus(id, status) {
  const todos = obterItemDoLocalStorage();
  const intId = Number(id);
  const novaTarefa = todos.find((todo) => todo.id === intId);
  const novoStatus =
    novaTarefa.status === "incompleta" ? "completa" : "incompleta";
  const indexTarefa = todos.indexOf(novaTarefa);
  todos.splice(indexTarefa, 1);
  novaTarefa.status = novoStatus;
  todos.splice(indexTarefa, 0, novaTarefa);
  localStorage.setItem("todos", JSON.stringify(todos));
}

function filtrarTarefas(e) {
  const todos = todoList.childNodes;
  todos.forEach((todo) => {
    if (
      e.target.value === "completa" &&
      todo.classList.contains("completed")
    ) {
      todo.style.display = "flex";
    } else if (
      e.target.value === "completa" &&
      !todo.classList.contains("completed")
    ) {
      todo.style.display = "none";
    } else if (
      e.target.value === "incompleta" &&
      !todo.classList.contains("completed")
    ) {
      todo.style.display = "flex";
    } else if (
      e.target.value === "incompleta" &&
      todo.classList.contains("completed")
    ) {
      todo.style.display = "none";
    } else {
      todo.style.display = "flex";
    }
  });
  setAggregatedToDos();
}

// Salvar tarefas no Local Storage
function salvarTarefasNoLocalStorage(novaTarefa) {
  const todos = obterItemDoLocalStorage();
  todos.push(novaTarefa);
  localStorage.setItem("todos", JSON.stringify(todos));
}

function isDuplicate(task) {
  const todos = obterItemDoLocalStorage();
  const duplicate = todos.find((todo) => todo.tarefa === task);
  return duplicate != undefined;
}

function abrirModal(cor, texto) {
  const popupText = document.querySelector(".popup-text");
  popupText.innerText = texto;
  modal.style.display = "block";
  modal.style.backgroundColor = cor;
  span.onclick = function () {
    modal.style.display = "none";
  };
  window.onclick = function (event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  };
}

function editarTarefa(tarefa, div) {
  const form = div.querySelector(".editform");
  const inputField = div.querySelector(`#edit-${tarefa.id}`);
  form.classList.toggle("hide");
  inputField.focus();
  inputField.select();

  const submitButton = div.querySelector(`#editBtn-${tarefa.id}`);
  submitButton.addEventListener("click", (e) => {
    e.preventDefault();
    const newTaskValue = inputField.value.trim();
    if (newTaskValue === "") {
      abrirModal("red", "A tarefa não pode ser vazia.");
      return;
    }

    if (isDuplicate(newTaskValue)) {
      abrirModal("red", "Tarefa já existe.");
      return;
    }

    tarefa.tarefa = newTaskValue;
    localStorage.setItem("todos", JSON.stringify(obterItemDoLocalStorage()));

    div.querySelector(".todo-item").innerText = newTaskValue;
    form.classList.add("hide");

    setAggregatedToDos();
  });
}

function verificarSeTodasTarefasEstaoConcluídas() {
  const todos = document.querySelectorAll(".todo");
  const incompletos = Array.from(todos).filter(
    (todo) => !todo.classList.contains("completed")
  );
  const botaoDeConcluir = document.querySelector("#complete-all");
  if (incompletos.length === 0) {
    botaoDeConcluir.classList.remove("hide");
  } else {
    botaoDeConcluir.classList.add("hide");
  }
}

function setAggregatedToDos() {
  // Esse método pode ser utilizado para atualização global do estado de agregação de tarefas
  console.log("Atualizando tarefas...");
  const todos = obterItemDoLocalStorage();
  const statusAggregator = todos.reduce(
    (agg, curr) => {
      if (curr.status === "incompleta") {
        agg.incompletas += 1;
      } else {
        agg.completas += 1;
      }
      return agg;
    },
    { completas: 0, incompletas: 0 }
  );
  console.log(statusAggregator);
}
